Readme for the ReadingCleaningBikeDataThenMappingIt notebook:
!!!THIS IS THE NOTEBOOK THAT HAS TO BE OPENED IN A SPECIAL MODE JUPYTER NOTEBOOK DUE TO LARGE ARRAYS!!!
The way I did it was by opening the Anaconda Prompt and entering the following line:
jupyter notebook --NotebookApp.iopub_data_rate_limit=1.0e10

Prerequistes:
In the same folder as the notebook, one needs the following file "SPOILER_bicycle_stations.csv", which should be obtainable
by running another notebook within the project files. However as the data might be classified, we did not upload the base data to the project,
so even running the "another notebook", will not yield results without having the original data.

Aside from the previous file, the user should also have the following list of files:
"bicycle_data/locations_201907_part1.csv"
"bicycle_data/locations_201907_part2.csv"
"bicycle_data/locations_201908_part1.csv"
"bicycle_data/locations_201908_part2.csv"
"bicycle_data/locations_201909.csv"
"bicycle_data/routes_201907.csv"
"bicycle_data/routes_201908.csv"
"bicycle_data/routes_201909.csv"
"Smart Bike Tartu_july 2019/routes_20190718.csv"
"Smart Bike Tartu_july 2019/locations_20190718.csv"
"Smart Bike Tartu_july 2019/routes_20190719.csv"
"Smart Bike Tartu_july 2019/locations_20190719.csv"
"Smart Bike Tartu_july 2019/routes_20190725.csv"
"Smart Bike Tartu_july 2019/locations_20190725.csv"
"Smart Bike Tartu_july 2019/routes_20190726.csv"
"Smart Bike Tartu_july 2019/locations_20190726.csv"

Finally, these files are needed:
"MapOfTartuModified.png"
"comicbd.ttf"
Which should be the only files that we can share without facing jailtime
The first one has an image of Tartu in it, made in Google Maps, that we use to map the data.
The second one is a font file for the best font on the market: Comic Sans (bold)


How to use the code (once the prerequisites are completed):
1. run all (this activates the methods and also cleans the data (as it was not defined as a method))
2. Check out the bottom of the notebook to find examples on how to run the main methods
3. Pretty much all of the main methods take 5-15 minutes each to run, so be patient
4. The code and methods itself should be commented well enough, so reading them should give the general idea as to what a certain method does.

How to use the code (if the prerequisites are not completed (For example some files are missing)):
1. Don't
2. Maybe removing some of the code will help, especially at the start where we are cleaning the data
	2.1 However in this case, it is unlikely that the main methods are working as intended
