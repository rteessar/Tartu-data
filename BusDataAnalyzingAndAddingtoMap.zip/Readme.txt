This zip file contains everything used to clean, combine and sort the bus data and it also contains the jupyter notebook file to add everything to a map.
To get the result all .ipynb files must be executed in Jupyter Notebook.

First part, "Cleaning data.ipynb" cleans the data of any unnecessary columns and NaN's.

Second in the list is "Combining data.ipynb" and the main purpose for this notebook is to combine all the smaller datasets into one large dataset.

After the second part data has to be sorted, "bus data sorting.ipynb" removes the unnecessary rows of data and puts the data the in correct form.

Finally to summarize it all, execute "Data to map.ipynb" which adds everything to map.