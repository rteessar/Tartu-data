This zip file contains everything used to clean, combine and sort the bus data and it also contains the jupyter notebook file to add everything to a map.

First you have to use the "Cleaning data.ipynb". This cleans the dataset of unnecessary columns and NaN values.

Second thing in the list is "Combining data.ipynb". This combines all the smaller datasets into one large dataset.

Third is the sorting part using the "bus data sorting.ipynb". This is used to remove the unnecessary rows of data and putting the data in correct form.

Finally there is the part "Data to map.ipynb" which adds everything to map.