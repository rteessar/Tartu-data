The notebooks provided in this zip file should be fairly logical to use and commented to help ease of usage. 

You should enter the path to the dataset in the first cells and the rest should work properly.